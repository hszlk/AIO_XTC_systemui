#!/system/bin/sh
# XTCSystemUI Rebuild (hand-written 1.8.00 clean-room) - dual-device module
#   W4 = Android 8.1 (SDK 27) -> payload 4100.zip (no audio-capture files: the 8.1
#        audio policy on this device exposes no remote_submix loopback device)
#   W5 = Android 11 (SDK 30) -> payload 5100.zip (adds screen-record audio restore)
MODID=XTCSystemUI_HS

[ -d "/data/adb/modules/$MODID" ] && /data/adb/magisk/busybox chattr -R -i "/data/adb/modules/$MODID" 2>/dev/null

SDK_VERSION=$(getprop ro.build.version.sdk)

if [ "$SDK_VERSION" = "27" ]; then
  ui_print "- Android 8.1 (SDK 27): installing 4100 payload"
  unzip -o "$ZIPFILE" '4100.zip' -d "$MODPATH" >/dev/null 2>&1
  cd "$MODPATH" && unzip -o "4100.zip" >/dev/null 2>&1 && rm -f "4100.zip"
  rm -f "$MODPATH/5100.zip"
elif [ "$SDK_VERSION" = "30" ]; then
  ui_print "- Android 11 (SDK 30): installing 5100 payload (with audio restore)"
  unzip -o "$ZIPFILE" '5100.zip' -d "$MODPATH" >/dev/null 2>&1
  cd "$MODPATH" && unzip -o "5100.zip" >/dev/null 2>&1 && rm -f "5100.zip"
  rm -f "$MODPATH/4100.zip"
else
  ui_print "! Unsupported SDK: $SDK_VERSION"
  abort
fi

# DO NOT call `pm uninstall com.android.systemui` here!
# It was in the first shell build and it removed the system package for user 0
# once the /data/app update was gone (the watch lost SystemUI entirely and the
# debug-signed APK cannot be reinstalled into shared uid android.uid.system).
# The /data/app update is instead handled by the last-loading `z` overlay module,
# which already carries the same hand-written APK.

set_perm_recursive "$MODPATH" 0 0 0755 0644
[ -d "$MODPATH/system/bin" ] && set_perm_recursive "$MODPATH/system/bin" 0 0 0755 0755
[ -d "$MODPATH/system/etc/permissions" ] && set_perm_recursive "$MODPATH/system/etc/permissions" 0 0 0755 0644
[ -d "$MODPATH/system/lib" ] && set_perm_recursive "$MODPATH/system/lib" 0 0 0755 0644
ui_print "- Install done. Reboot to apply."
